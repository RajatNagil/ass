package com.cg.eis.service;
public interface EmployeeService{
   public String findInsuranceScheme(long salary,String designation); 
}



