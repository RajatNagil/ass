public class Account {
	long accNum;
	double balance;
	Persons accHolder;
	public Account(){}
	public Account(long accNum, double balance, Persons accHolder) {
		this.accNum = accNum;
		this.balance = balance;
		this.accHolder = accHolder;
	}
	public long getAccNum(){
		return accNum;
	}
	public double getBalance(){
		System.out.println("The updated balance is:"+balance);
		return balance;
	}
	public Persons getAccHolder(){
		return accHolder;
	}
	public void setAccNum(long accNum){
		this.accNum=accNum;
	}
	public void setBalance(double balance){
		this.balance=balance;
		if(balance>=500){
			System.out.println("The account is enabled");
		}
		else{
			System.out.println("The account is disabled");
		}
	}
	public Persons getaccHolder(){
		return accHolder;
	}
	public void setaccHolder(Persons accHolder){
		this.accHolder=accHolder;
	}
	public void deposit(double dAmount){
		balance=balance+dAmount;
	}
	public String toString(){
		return "Account[AccNum="+accNum+",balance="+balance+"]";
	}
	public void withdraw(double m) throws OverDraftLimitExceeded,BalanceNotSufficientException
	{
		balance=balance-m;
	}
}