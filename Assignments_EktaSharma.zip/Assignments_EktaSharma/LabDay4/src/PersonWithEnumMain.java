public class PersonWithEnumMain {

	public static void main(String[] args)
	{
		PersonwithEnum obj = new PersonwithEnum("Ekta","Sharma",Gender.F,"9876543210");
		obj.display();

	}

}