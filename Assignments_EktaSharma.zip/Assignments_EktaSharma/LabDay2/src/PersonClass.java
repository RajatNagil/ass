public class PersonClass {
	String fName;
	String lName;
	Gender gender;
	long phNo;
	public PersonClass(){
		fName=null;
		lName=null;
		gender=Gender.N;
		phNo=0l;
	}
	public PersonClass(String fName,String lName,Gender gender){   

		this.fName=fName;
		this.lName=lName;
		this.gender=gender;
		System.out.println("\nCalling Parametrized Constructor");
	}
	public long PhoneNo(long phNo){
		return phNo;
	}
	public String dispDetails(){
		return "First Name-"+fName+"\n"+"Last Name-"+lName+"\n"+"Gender-"+gender;
	}
	public String getfName(){
		return fName;
	}	
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}	
}		 
