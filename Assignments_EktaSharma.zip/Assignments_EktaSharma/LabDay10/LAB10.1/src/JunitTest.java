import org.junit.Assert;
import org.junit.Test;
public class JunitTest {
	@Test
	public void testGetFirstName(){
		Person per = new Person("eKTA","sHARMA");
		Assert.assertEquals("eKTA",per.getFirstName());
	}
	@Test
	public void testGetLastName(){
		Person per= new Person("rAJAT","eKTA");
		Assert.assertEquals("eKTA",per.getLastName());
	} 
}