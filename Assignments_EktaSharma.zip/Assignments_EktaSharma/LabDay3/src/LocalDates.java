import java.time.LocalDate;
import java.time.Period;
public class LocalDates {
	public static void main(String[] args) {
		LocalDate p1Date=LocalDate.of(1997,02,01);
		LocalDate p2Date=LocalDate.of(1997,8,17);
		Period diff=Period.between(p1Date,p2Date);
		System.out.printf("\n Difference  is: %d years,%d months, %d days old \n \n",diff.getYears(),diff.getMonths(),diff.getDays());	
	}
}

