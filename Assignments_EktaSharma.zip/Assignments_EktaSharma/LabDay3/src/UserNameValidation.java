import java.util.Scanner;
public class UserNameValidation {
	public Boolean testString(String str){
		String str1="_job";
		int l=str.length();
		String subStr1=str.substring(l-4,l);
		if((str1.equals(subStr1))&&l>=12){
			return true;
		}
		else{
			return false;
		}
	}
	public static void main(String[] args){
		System.out.println("Enter User Name:");
		Scanner s=new Scanner(System.in);
		String str=s.next();
		UserNameValidation user=new UserNameValidation();
		System.out.println(user.testString(str));    
	}
}
