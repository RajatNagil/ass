import java.util.Scanner;
public class UsernameAndPasswordValidationUsingLambdaImpl {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		UsernameAndPasswordValidationUsingLambda usernameAndPasswordValidation=(username, password) -> {
			System.out.println("Enter Username:");
			String usernameInput=sc.nextLine();
			System.out.println("Enter Password:");
			String passwordInput=sc.nextLine();
			if(username.equals(usernameInput) && password.contentEquals(passwordInput))
				return true;
			return false;
		};
		if(usernameAndPasswordValidation.usernameAndPasswordValidation("Ekta", "1117"))
			System.out.println("Correct! You Are Successfully Logged In");
		else
			System.out.println("Incorrect username or Password");
	}
}
