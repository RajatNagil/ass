public interface UsernameAndPasswordValidationUsingLambda {
	boolean usernameAndPasswordValidation(String username, String password);
}
