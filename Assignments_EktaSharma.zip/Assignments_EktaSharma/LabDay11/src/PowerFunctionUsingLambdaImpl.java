import java.util.Scanner;
public class PowerFunctionUsingLambdaImpl {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value of x :");
		double x=sc.nextDouble();
		System.out.println("Enter the value of y :");
		double y=sc.nextDouble();
		PowerFunctionUsingLambda powerOfx=(n1,n2)->{
			double temp=n1;
			for(int i=1 ; i<n2; i++)
				n1*=temp;
			return n1;
		};
		System.out.println(x+"\t Raised to the power \t "+y+"\t Is \t"+powerOfx.calculatePower(x, y));
	}
}