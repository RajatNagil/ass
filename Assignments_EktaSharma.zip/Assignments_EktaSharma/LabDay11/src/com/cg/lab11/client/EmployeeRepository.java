package com.cg.lab11.client;

public class EmployeeRepository {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
