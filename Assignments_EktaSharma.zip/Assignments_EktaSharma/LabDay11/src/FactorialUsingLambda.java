public interface FactorialUsingLambda {
	public double calcFactorial(int n);
}
